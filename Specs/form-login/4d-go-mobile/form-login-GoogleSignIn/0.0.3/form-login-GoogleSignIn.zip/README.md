# Google Sign In
Let user login with his Google account.

You must edit [server_client_id](https://github.com/4d-go-mobile/form-login-GoogleSignIn/blob/e40d7b44c8e5f0acdd09258286e619705914d6ad/android/res/values/strings.xml) value with your client id.

To get your client id, read more about configuring a Google API project.

https://developers.google.com/identity/sign-in/android/start#configure-a-google-api-project
