<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-formatter-Mail/blob/master/formatter.png" alt=“Mail” height="auto" width="200"></p>

## Mail

* **Format:** Text ⟶ Mail
* **Function:** open the mail app on click
* **Type:** Swift formatter

## How to integrate

* To use a custom formatter, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/formatters folder.
* Then drop the formatter folder into it.
