<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-formatter-Phone/blob/master/formatter.png" alt="Phone” height="auto" width="200"></p>

## Phone

* **Format:** Number ⟶ Phone number
* **Function:** call the number on click
* **Type:** Swift formatter

## How to integrate

* To use a custom formatter, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/formatters folder.
* Then drop the formatter folder into it.
