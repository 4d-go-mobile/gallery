<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-formatter-Html/blob/master/formatter.png" alt=“HTML” height="auto" width="200"></p>

## Html

* **Format:** Text ⟶ html
* **Function:** add style
* **Type:** Swift formatter
* Support 4D multistyle text

## How to integrate

* To use a custom formatter, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/formatters folder.
* Then drop the formatter folder into it.
