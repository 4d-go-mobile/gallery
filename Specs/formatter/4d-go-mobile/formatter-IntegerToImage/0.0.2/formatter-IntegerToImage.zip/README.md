<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-formatter-IntegerToImage/blob/master/formatter.png" alt="Int to Image” height="auto" width="200"></p>

## Int to Image

* **Format:** Integer ⟶ Image
* **Type:** basic formatter

## How to integrate

* To use a custom formatter, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/formatters folder.
* Then drop the formatter folder into it. 
