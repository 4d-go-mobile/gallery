<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-list-VisualTable/blob/master/template.gif" alt="Visual Table" height="auto" width="300"></p>

## Visual Table

* **Type:** Table
* **Section:** available
* **Actions:** cell left swipe
* **Image required:** yes

## How to integrate

* To use a list form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/list folder.
* Then drop the list form folder into it.
