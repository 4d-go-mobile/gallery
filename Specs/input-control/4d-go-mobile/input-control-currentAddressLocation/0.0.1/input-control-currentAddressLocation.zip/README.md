# CurrentLocationAddressRow

Action parameter input control that auto fill the current location address.

![preview](formatter.png)

The field is not editable by user.
