# CurrentLocationRow

Action parameter input control that auto fill the current location of user ie. latitude longitude.

![preview](formatter.png)

The field is not editable by user.