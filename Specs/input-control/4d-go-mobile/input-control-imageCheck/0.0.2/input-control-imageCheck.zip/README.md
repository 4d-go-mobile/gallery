# ImageCheck

Example to use image for boolean

![preview](formatter.png)
