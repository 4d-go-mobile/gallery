<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-detail-ParallaxDetail/blob/master/template.gif" alt="Parallax Detail" height="auto" width="300"></p>

## Parallax Detail

* **Included ressources:** yes
* **Actions:** included
* **Image required:** yes

## How to integrate

* To use a custom detail form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/detail folder.
* Then drop the detail form folder into it.
