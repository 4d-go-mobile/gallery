<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-detail-VisualContact/blob/master/template.gif" alt="Visual Contact" height="auto" width="300"></p>

## Visual Contact

[![Language][swift-shield]][swift-url]
[![check][check-shield]][check-url]

* **Actions:** included
* **Image required:** yes

## How to integrate

* To use a detail form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/detail folder.
* Then drop the detail form folder into it.

<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->
[swift-shield]: http://img.shields.io/badge/language-swift-orange.svg?style=flat
[swift-url]: https://developer.apple.com/swift/
[check-shield]: https://github.com/DavAz4D/4d-for-ios-form-detail-VisualContact/workflows/check/badge.svg
[check-url]: https://github.com/DavAz4D/4d-for-ios-form-detail-VisualContact/actions?workflow=check
