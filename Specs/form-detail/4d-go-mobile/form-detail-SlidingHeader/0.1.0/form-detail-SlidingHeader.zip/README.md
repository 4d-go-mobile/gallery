<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-detail-SlidingHeader/blob/master/template.gif" alt="Sliding Header" height="auto" width="300"></p>

## Sliding Header

* **Actions:** included
* **Image required:** no

## How to integrate

* To use a detail form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/detail folder.
* Then drop the detail form folder into it.
